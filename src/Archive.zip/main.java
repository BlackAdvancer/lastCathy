public class main {
    public static void main(String[] args) {
        BranchUI branchUI = new BranchUI();
        branchUI.setResizable(false);
        branchUI.setVisible(true);
    }
}
