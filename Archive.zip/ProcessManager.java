import javax.swing.*;

public class ProcessManager extends JFrame {

}
